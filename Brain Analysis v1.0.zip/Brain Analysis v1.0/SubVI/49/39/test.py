import cv2
import os
import skimage
import numpy as np
#from skimage.morphology import watershed
from skimage.segmentation import watershed
from skimage.feature import peak_local_max
from scipy import ndimage 
import matplotlib.pyplot as plt 
from matplotlib import pyplot as plt
from skimage.morphology import extrema
from skimage import io
#import noisereduce as nr


def auto(image_path, GaussianBlur_kernel_x, GaussianBlur_kernel_y , histogram_bins_value,
MrphologyEx_kernel_x, MrphologyEx_kernel_y, morphologyEx_iterations, distanceTransform_maskSize, Erosion_Iterations, Dilation_Iterations,
auto_canny_sigma, dpii):


	def auto_canny(image, sigma=auto_canny_sigma/100):  #sigma value can be used to vary the percentage thresholds that are determined based on simple statistics.
		v = np.median(image)
		lower = int(max(0, (1.0 - sigma) * v))
		upper = int(min(255, (1.0 + sigma) * v))
		edged = cv2.Canny(image, lower, upper)
		return edged

	#img = io.imread("C:/Users/Sanaullah/3D Objects/Brain/working/data/y169.jpeg")
	img = io.imread(image_path)

	#path1=r"/Users/sanaullah/Desktop/Code/Image/3.png"  
	#img           = cv2.imread(img)
	gray          = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
	

################# THRESH_OTSU value start

	#img = cv2.GaussianBlur(img, (5, 5), 0)   # GaussianBlur with a 5 x 5 kernel to help remove high frequency noise
	img = cv2.GaussianBlur(img, (GaussianBlur_kernel_x, GaussianBlur_kernel_y), 0)

	#bins_num = 256  # The parameter bins determines the number of “bins” to use for the histogram. We pass in 256 because we want to see the pixel count for each of the 256 possible values in the grayscale image.
	bins_num = histogram_bins_value

	# Get the image histogram
	hist, bin_edges = np.histogram(img, bins=bins_num)
	
	# Get normalized histogram if it is required
	hist = np.divide(hist.ravel(), hist.max())
	
	# Calculate centers of bins
	bin_mids = (bin_edges[:-1] + bin_edges[1:]) / 2.
	
	# Iterate over all thresholds (indices) and get the probabilities w1(t), w2(t)
	weight1 = np.cumsum(hist)
	weight2 = np.cumsum(hist[::-1])[::-1]
	
	# Get the class means mu0(t)
	mean1 = np.cumsum(hist * bin_mids) / weight1
	# Get the class means mu1(t)
	mean2 = (np.cumsum((hist * bin_mids)[::-1]) / weight2[::-1])[::-1]
	
	inter_class_variance = weight1[:-1] * weight2[1:] * (mean1[:-1] - mean2[1:]) ** 2
	
	# Maximize the inter_class_variance function val
	index_of_max_val = np.argmax(inter_class_variance)
	
	threshold1 = bin_mids[:-1][index_of_max_val]

	file_path = 'thresholding_result.txt'
	if os.path.isfile(file_path):
		os.remove(file_path)
		with open('thresholding_result.txt', 'w') as f:
			f.write(str(threshold1))
	else:
		with open('thresholding_result.txt', 'w') as f:
			f.write(str(threshold1))

	#print("Otsu's algorithm implementation thresholding result: ", threshold)


################# THRESH_OTSU value end





	#ShowImage('Brain MRI',gray,'gray')
	plt.imsave('Brain_MRI.png', gray, cmap=plt.cm.gray, dpi=dpii) 
	
	#ret, thresh = cv2.threshold(gray,155,255, cv2.THRESH_OTSU)		# threshold values set 155
	ret, thresh = cv2.threshold(gray,threshold1, 255, cv2.THRESH_OTSU)	
	
	#ShowImage("Otsu's Thresholding image",thresh,'gray')
	plt.imsave('Otsus_Thresholding_image.png', thresh, cmap=plt.cm.gray, dpi=dpii)

	#(T, threshInv) = cv2.threshold(gray, 155, 255,cv2.THRESH_BINARY_INV)   # threshold values set 155
	(T, threshInv) = cv2.threshold(gray,threshold1, 255, cv2.THRESH_BINARY_INV)


	#ShowImage("Inv's Thresholding image", threshInv, "gray")
	plt.imsave('Invs_Thresholding_image.png', threshInv, cmap=plt.cm.gray, dpi=dpii)


	ret, markers = cv2.connectedComponents(thresh)
	marker_area = [np.sum(markers==m) for m in range(np.max(markers)) if m!=0] 
	largest_component = np.argmax(marker_area)+1                        
	brain_mask = markers==largest_component
	brain_out = img.copy()
	brain_out[brain_mask==False] = (0,0,0)
	#img = cv2.imread(path1)
	gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

	#ret, thresh = cv2.threshold(gray,155,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU) # threshold values set 155
	ret, thresh = cv2.threshold(gray,threshold1, 255, cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)

	#kernel = np.ones((3,3),np.uint8)                                          # 3×3 kernel filled with ones for morphologyEx
	kernel = np.ones((MrphologyEx_kernel_x,MrphologyEx_kernel_y),np.uint8)
	
	
	#opening = cv2.morphologyEx(thresh,cv2.MORPH_OPEN,kernel, iterations = 2)    # Iterations Number of times erosion and dilation are applied. default 1
	opening = cv2.morphologyEx(thresh,cv2.MORPH_OPEN,kernel, iterations = morphologyEx_iterations)
	

	sure_bg = cv2.dilate(opening,kernel,iterations=3)
	#dist_transform = cv2.distanceTransform(opening,cv2.DIST_L2,5)         # distanceTransform maskSize = 5
	dist_transform = cv2.distanceTransform(opening,cv2.DIST_L2, distanceTransform_maskSize)

	ret, sure_fg = cv2.threshold(dist_transform,0.7*dist_transform.max(),255,0)
	sure_fg = np.uint8(sure_fg)
	unknown = cv2.subtract(sure_bg,sure_fg)
	ret, markers = cv2.connectedComponents(sure_fg)
	markers = markers+1
	markers[unknown==255] = 0
	markers = cv2.watershed(img,markers)
	img[markers == -1] = [255,0,0]
	im1 = cv2.cvtColor(img,cv2.COLOR_HSV2RGB)

	#ShowImage('Watershed segmented image',im1,'gray')
	plt.imsave('Watershed_segmented_image.png', im1, cmap=plt.cm.gray, dpi=dpii)


	brain_mask = np.uint8(brain_mask)
	#kernel = np.ones((40,40),np.uint8)
	kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (10, 5))
	closing = cv2.morphologyEx(brain_mask, cv2.MORPH_CLOSE, kernel)

	closed = cv2.erode(closing, None, iterations = Erosion_Iterations)   				# Iterations Number of times erosion
	closed = cv2.dilate(closing, None, iterations = Dilation_Iterations)					# Iterations Number of times dilation

	#ShowImage(' Image after Erosion & Dilation', closed, 'gray')
	plt.imsave('Image_after_Erosion_&_Dilation.png', closed, cmap=plt.cm.gray, dpi=dpii)
	brain_out = img.copy()
	brain_out[closing==False] = (0,0,0)

	canny = auto_canny(closing)

	(cnts, _) = cv2.findContours(canny.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
	cv2.drawContours(img, cnts, -1, (0, 0, 255), 2)

	#cv2.imshow("The Final Image",img)
	plt.imsave('The_Final_Image.png', img, cmap=plt.cm.gray, dpi=dpii)
	cv2.waitKey(0)
	cv2.destroyAllWindows()




	file_path = 'results.txt'
	if os.path.isfile(file_path):
			os.remove(file_path)
			with open('results.txt', 'w') as f:
					f.write(str("Change to Traing mode for detail results "))
	else:
			with open('results.txt', 'w') as f:
					f.write(str("Change to Traing mode for detail results "))

	
	
	file_path = 'mse.txt'
	if os.path.isfile(file_path):
			os.remove(file_path)
			with open('mse.txt', 'w') as f:
					f.write(str("Change to Traing mode for detail results"))
	else:
			with open('mse.txt', 'w') as f:
					f.write(str("Change to Traing mode for detail results"))



	return (0)
	

################################################################################################################################
###############################################################################################################################


def manual(image_path, GaussianBlur_kernel_x, GaussianBlur_kernel_y , histogram_bins_value, Threshold_Value_Manual_Selection,
MrphologyEx_kernel_x, MrphologyEx_kernel_y, morphologyEx_iterations, distanceTransform_maskSize, Erosion_Iterations, Dilation_Iterations,
auto_canny_sigma, dpii):


	def auto_canny(image, sigma=auto_canny_sigma/100):  #sigma value can be used to vary the percentage thresholds that are determined based on simple statistics.
		v = np.median(image)
		lower = int(max(0, (1.0 - sigma) * v))
		upper = int(min(255, (1.0 + sigma) * v))
		edged = cv2.Canny(image, lower, upper)
		return edged

	#img = io.imread("C:/Users/Sanaullah/3D Objects/Brain/working/data/y169.jpeg")
	img = io.imread(image_path)

	#path1=r"/Users/sanaullah/Desktop/Code/Image/3.png"  
	#img           = cv2.imread(img)
	gray          = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
	

################# THRESH_OTSU value start

	#img = cv2.GaussianBlur(img, (5, 5), 0)   # GaussianBlur with a 5 x 5 kernel to help remove high frequency noise
	img = cv2.GaussianBlur(img, (GaussianBlur_kernel_x, GaussianBlur_kernel_y), 0)

	#bins_num = 256  # The parameter bins determines the number of “bins” to use for the histogram. We pass in 256 because we want to see the pixel count for each of the 256 possible values in the grayscale image.
	bins_num = histogram_bins_value

	# Get the image histogram
	hist, bin_edges = np.histogram(img, bins=bins_num)
	
	# Get normalized histogram if it is required
	hist = np.divide(hist.ravel(), hist.max())
	
	# Calculate centers of bins
	bin_mids = (bin_edges[:-1] + bin_edges[1:]) / 2.
	
	# Iterate over all thresholds (indices) and get the probabilities w1(t), w2(t)
	weight1 = np.cumsum(hist)
	weight2 = np.cumsum(hist[::-1])[::-1]
	
	# Get the class means mu0(t)
	mean1 = np.cumsum(hist * bin_mids) / weight1
	# Get the class means mu1(t)
	mean2 = (np.cumsum((hist * bin_mids)[::-1]) / weight2[::-1])[::-1]
	
	inter_class_variance = weight1[:-1] * weight2[1:] * (mean1[:-1] - mean2[1:]) ** 2
	
	# Maximize the inter_class_variance function val
	index_of_max_val = np.argmax(inter_class_variance)
	
	threshold = bin_mids[:-1][index_of_max_val]


	#print("Otsu's algorithm implementation thresholding result: ", threshold)


################# THRESH_OTSU value end





	#ShowImage('Brain MRI',gray,'gray')
	plt.imsave('Brain_MRI.png', gray, cmap=plt.cm.gray, dpi=dpii) 
	
	#ret, thresh = cv2.threshold(gray,155,255, cv2.THRESH_OTSU)		# threshold values set 155
	ret, thresh = cv2.threshold(gray,Threshold_Value_Manual_Selection,255, cv2.THRESH_OTSU)	
	
	#ShowImage("Otsu's Thresholding image",thresh,'gray')
	plt.imsave('Otsus_Thresholding_image.png', thresh, cmap=plt.cm.gray, dpi=dpii)

	#(T, threshInv) = cv2.threshold(gray, 155, 255,cv2.THRESH_BINARY_INV)   # threshold values set 155
	(T, threshInv) = cv2.threshold(gray,Threshold_Value_Manual_Selection,255, cv2.THRESH_BINARY_INV)


	#ShowImage("Inv's Thresholding image", threshInv, "gray")
	plt.imsave('Invs_Thresholding_image.png', threshInv, cmap=plt.cm.gray, dpi=dpii)


	ret, markers = cv2.connectedComponents(thresh)
	marker_area = [np.sum(markers==m) for m in range(np.max(markers)) if m!=0] 
	largest_component = np.argmax(marker_area)+1                        
	brain_mask = markers==largest_component
	brain_out = img.copy()
	brain_out[brain_mask==False] = (0,0,0)
	#img = cv2.imread(path1)
	gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

	#ret, thresh = cv2.threshold(gray,155,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU) # threshold values set 155
	ret, thresh = cv2.threshold(gray,Threshold_Value_Manual_Selection,255, cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)

	#kernel = np.ones((3,3),np.uint8)                                          # 3×3 kernel filled with ones for morphologyEx
	kernel = np.ones((MrphologyEx_kernel_x,MrphologyEx_kernel_y),np.uint8)
	
	
	#opening = cv2.morphologyEx(thresh,cv2.MORPH_OPEN,kernel, iterations = 2)    # Iterations Number of times erosion and dilation are applied. default 1
	opening = cv2.morphologyEx(thresh,cv2.MORPH_OPEN,kernel, iterations = morphologyEx_iterations)
	

	sure_bg = cv2.dilate(opening,kernel,iterations=3)
	#dist_transform = cv2.distanceTransform(opening,cv2.DIST_L2,5)         # distanceTransform maskSize = 5
	dist_transform = cv2.distanceTransform(opening,cv2.DIST_L2, distanceTransform_maskSize)

	ret, sure_fg = cv2.threshold(dist_transform,0.7*dist_transform.max(),255,0)
	sure_fg = np.uint8(sure_fg)
	unknown = cv2.subtract(sure_bg,sure_fg)
	ret, markers = cv2.connectedComponents(sure_fg)
	markers = markers+1
	markers[unknown==255] = 0
	markers = cv2.watershed(img,markers)
	img[markers == -1] = [255,0,0]
	im1 = cv2.cvtColor(img,cv2.COLOR_HSV2RGB)

	#ShowImage('Watershed segmented image',im1,'gray')
	plt.imsave('Watershed_segmented_image.png', im1, cmap=plt.cm.gray, dpi=dpii)


	brain_mask = np.uint8(brain_mask)
	#kernel = np.ones((40,40),np.uint8)
	kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (10, 5))
	closing = cv2.morphologyEx(brain_mask, cv2.MORPH_CLOSE, kernel)

	closed = cv2.erode(closing, None, iterations = Erosion_Iterations)   				# Iterations Number of times erosion
	closed = cv2.dilate(closing, None, iterations = Dilation_Iterations)					# Iterations Number of times dilation

	#ShowImage(' Image after Erosion & Dilation', closed, 'gray')
	plt.imsave('Image_after_Erosion_&_Dilation.png', closed, cmap=plt.cm.gray, dpi=dpii)
	brain_out = img.copy()
	brain_out[closing==False] = (0,0,0)

	canny = auto_canny(closed)

	(cnts, _) = cv2.findContours(canny.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
	cv2.drawContours(img, cnts, -1, (0, 0, 255), 2)

	#cv2.imshow("The Final Image",img)
	plt.imsave('The_Final_Image.png', img, cmap=plt.cm.gray, dpi=dpii)
	cv2.waitKey(0)
	cv2.destroyAllWindows()



	file_path = 'results.txt'
	if os.path.isfile(file_path):
			os.remove(file_path)
			with open('results.txt', 'w') as f:
					f.write(str("Change to Traing mode"+ '\n'))
					f.write(str("For detail results "))

	else:
			with open('results.txt', 'w') as f:
					f.write(str("Change to Traing mode"+ '\n'))
					f.write(str("For detail results "))
	
	
	file_path = 'mse.txt'
	if os.path.isfile(file_path):
			os.remove(file_path)
			with open('mse.txt', 'w') as f:
					f.write(str("Change to Traing mode for detail results"))

	else:
			with open('mse.txt', 'w') as f:
					f.write(str("Change to Traing mode for detail results"))




	return (0)

def lana(image): 
	image=cv2.GaussianBlur(image,(5,5),0)   # GaussianBlur with a 5 x 5 kernel to help remove high frequency noise
	distance = ndimage.distance_transform_edt(image)
	local_maxi = peak_local_max(distance, indices=False, footprint=np.ones((3, 3)), labels=image)
	markers = skimage.morphology.label(local_maxi)
	labels_ws = skimage.segmentation.watershed(-distance, markers, mask=image)

	#plt.imshow(labels_ws, cmap=plt.cm.gray, interpolation='nearest')
	#plt.show(block=False)


#def main(image_path, GaussianBlur_kernel_x, GaussianBlur_kernel_y , histogram_bins_value, Threshold_Value_Manual_Selection,
#MrphologyEx_kernel_x, MrphologyEx_kernel_y, morphologyEx_iterations, distanceTransform_maskSize):

#image_path = "C:/Users/Sanaullah/3D Objects/Brain/working/data/y169.jpeg"

#auto(image_path, 5, 5, 256, 155, 3, 3, 2, 5, 14, 13, 33)