import cv2
import numpy as np
import os
import glob
import mahotas as mt
import pandas as pd
from sklearn.svm import LinearSVC 
import SimpleITK
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler 
from sklearn.metrics import (precision_score, recall_score,f1_score, accuracy_score,mean_squared_error,mean_absolute_error, roc_curve, classification_report,auc)
from sklearn.metrics import precision_recall_fscore_support as score 
from sklearn.metrics import accuracy_score 
import em 
import test
import warnings 
from sklearn.ensemble import RandomForestClassifier 

def manual(image_path, GaussianBlur_kernel_x, GaussianBlur_kernel_y , histogram_bins_value, Threshold_Value_Manual_Selection,
MrphologyEx_kernel_x, MrphologyEx_kernel_y, morphologyEx_iterations, distanceTransform_maskSize, Erosion_Iterations, Dilation_Iterations,
auto_canny_sigma, dpii, Testing_Images, Training_Images):

        image_path = image_path
        GaussianBlur_kernel_x = GaussianBlur_kernel_x
        GaussianBlur_kernel_y = GaussianBlur_kernel_y
        histogram_bins_value = histogram_bins_value
        Threshold_Value_Manual_Selection = Threshold_Value_Manual_Selection
        MrphologyEx_kernel_x = MrphologyEx_kernel_x
        MrphologyEx_kernel_y = MrphologyEx_kernel_y
        morphologyEx_iterations = morphologyEx_iterations
        distanceTransform_maskSize = distanceTransform_maskSize
        Erosion_Iterations = Erosion_Iterations
        Dilation_Iterations = Dilation_Iterations
        auto_canny_sigma = auto_canny_sigma
        dpii = dpii

        test.manual(image_path, GaussianBlur_kernel_x, GaussianBlur_kernel_y , histogram_bins_value, Threshold_Value_Manual_Selection,
        MrphologyEx_kernel_x, MrphologyEx_kernel_y, morphologyEx_iterations, distanceTransform_maskSize, Erosion_Iterations, Dilation_Iterations,
        auto_canny_sigma, dpii)




        def FeatureExtract(image):
                textures = mt.features.haralick(image)
                mean = textures.mean(axis=0)       
                return mean 

        #train_path = "data/train/list"
        #test_path = "data/test/list"
        #pathd=r"data/train/list.txt"
        #patht=r"data/test/list.txt"

        train_path1 = Training_Images
        train_path = train_path1 + "/list"
        pathd = r'%s' % train_path1 + "/list.txt"


        test_path1 = Testing_Images
        test_path = test_path1 + "/list"
        patht = r'%s' % test_path1 + "/list.txt"

        warnings.filterwarnings("ignore")      
        train_names = os.listdir(train_path) 
        print (train_names)
        train_features = []
        train_labels = []
        i = 1
        idxSlice = 50
        traindata = pd.read_csv(pathd)
        testdata = pd.read_csv(patht)
        #print ("Texture Extraction...")
        for train_name in train_names:
                cur_path = train_path + "/" + train_name
                cur_label = train_name	
                i = 1
                for fileName in glob.glob(train_path + "/*.mha"): 
                        print ("Process image - {} in {}".format(i, cur_label))
                        imgT1Original = SimpleITK.ReadImage(fileName)
                        image = SimpleITK.GetArrayFromImage(SimpleITK.Tile(imgT1Original[:, :, idxSlice],(2, 1, 0))) 
                        seg = cv2.imread("seg1"+str(i)+".png") 
                        features = FeatureExtract(image) 
                        train_features.append(features)
                        train_labels.append(cur_label)
                        i += 1 

        #clf_svm = LinearSVC(random_state = 9) 
        clf = RandomForestClassifier(max_depth=2, random_state = 9)
        clf.fit(train_features, train_labels) 

        test_label = [] 
        pred_labels = [] 
        #print ("Process Test model...")
        for fileName in glob.glob(test_path + "/*.mha"):
                test_label = os.listdir(test_path)

                imgT1Original = SimpleITK.ReadImage(fileName)
                image = SimpleITK.GetArrayFromImage(SimpleITK.Tile(imgT1Original[:, :, idxSlice],(2, 1, 0))) 
                test.lana(image) 
                features = FeatureExtract(image) 
                prediction = clf.predict(features.reshape(1, -1))[0] 
                pred_labels.append(prediction) 
        y_train1 = traindata
        y_pred = testdata
        accuracy = accuracy_score(y_train1, y_pred)
        recall = recall_score(y_train1, y_pred , average="binary")
        precision = precision_score(y_train1, y_pred , average="binary")
        f1 = f1_score(y_train1, y_pred , average="binary")


        mse = mean_squared_error(y_train1, y_pred)





        file_path = 'results.txt'
        if os.path.isfile(file_path):
                os.remove(file_path)
                with open('results.txt', 'w') as f:
                        f.write(str("Accuracy %.3f" %accuracy + '\n'))
                        f.write(str("Precision %.3f" %precision + '\n'))
                        f.write(str("Racall %.3f" %recall + '\n'))
                        f.write(str("FScore %.3f" %f1 + '\n'))
        else:
                with open('results.txt', 'w') as f:
                        f.write(str("Accuracy %.3f" %accuracy + '\n'))
                        f.write(str("Precision %.3f" %precision + '\n'))
                        f.write(str("Racall %.3f" %recall + '\n'))
                        f.write(str("FScore %.3f" %f1 + '\n'))

        file_path = 'mse.txt'
        if os.path.isfile(file_path):
                os.remove(file_path)
                with open('mse.txt', 'w') as f:
                        f.write(str("MSE %.3f" %mse))

        else:
                with open('mse.txt', 'w') as f:
                        f.write(str("MSE %.3f" %mse))

        return(0)

        #import pandas as pd

        #clsf_report = pd.DataFrame(classification_report(y_true = y_train1, y_pred = y_pred, output_dict=True)).transpose()
        #clsf_report.to_csv('Your Classification Report Name.csv', index= True)


        """======================
        Segmentation Results:
        ======================
        Accuracy
        0.929

        Precision
        0.998

        Racall
        0.915

        MSE 0.071
        MAE 0.071
        """

################################################################################################################################
################################################################################################################################
################################################################################################################################

def auto(image_path, GaussianBlur_kernel_x, GaussianBlur_kernel_y , histogram_bins_value,
MrphologyEx_kernel_x, MrphologyEx_kernel_y, morphologyEx_iterations, distanceTransform_maskSize, Erosion_Iterations, Dilation_Iterations,
auto_canny_sigma, dpii, Testing_Images, Training_Images):

        image_path = image_path
        GaussianBlur_kernel_x = GaussianBlur_kernel_x
        GaussianBlur_kernel_y = GaussianBlur_kernel_y
        histogram_bins_value = histogram_bins_value
        MrphologyEx_kernel_x = MrphologyEx_kernel_x
        MrphologyEx_kernel_y = MrphologyEx_kernel_y
        morphologyEx_iterations = morphologyEx_iterations
        distanceTransform_maskSize = distanceTransform_maskSize
        Erosion_Iterations = Erosion_Iterations
        Dilation_Iterations = Dilation_Iterations
        auto_canny_sigma = auto_canny_sigma
        dpii = dpii

        test.auto(image_path, GaussianBlur_kernel_x, GaussianBlur_kernel_y , histogram_bins_value, MrphologyEx_kernel_x, 
        MrphologyEx_kernel_y, morphologyEx_iterations, distanceTransform_maskSize, Erosion_Iterations, Dilation_Iterations,
        auto_canny_sigma, dpii) 




        def FeatureExtract(image):
                textures = mt.features.haralick(image)
                mean = textures.mean(axis=0)       
                return mean 


        #train_path = "data/train/list"
        #test_path = "data/test/list"
        #pathd=r"data/train/list.txt"
        #patht=r"data/test/list.txt"

        train_path1 = Training_Images
        train_path = train_path1 + "/list"
        pathd = r'%s' % train_path1 + "/list.txt"


        test_path1 = Testing_Images
        test_path = test_path1 + "/list"
        patht = r'%s' % test_path1 + "/list.txt"

        warnings.filterwarnings("ignore")      
        train_names = os.listdir(train_path) 
        print (train_names)
        train_features = []
        train_labels = []
        i = 1
        idxSlice = 50
        traindata = pd.read_csv(pathd)
        testdata = pd.read_csv(patht)
        print ("Texture Extraction...")
        for train_name in train_names:
                cur_path = train_path + "/" + train_name
                cur_label = train_name	
                i = 1
                for fileName in glob.glob(train_path + "/*.mha"): 
                        print ("Process image - {} in {}".format(i, cur_label))
                        imgT1Original = SimpleITK.ReadImage(fileName)
                        image = SimpleITK.GetArrayFromImage(SimpleITK.Tile(imgT1Original[:, :, idxSlice],(2, 1, 0))) 
                        seg = cv2.imread("seg1"+str(i)+".png") 
                        features = FeatureExtract(image) 
                        train_features.append(features)
                        train_labels.append(cur_label)
                        i += 1 

        #clf_svm = LinearSVC(random_state = 9) 
        clf = RandomForestClassifier(max_depth=2, random_state = 9)
        clf.fit(train_features, train_labels) 

        test_label = [] 
        pred_labels = [] 
        print ("Process Test model...")
        for fileName in glob.glob(test_path + "/*.mha"):
                test_label = os.listdir(test_path)

                imgT1Original = SimpleITK.ReadImage(fileName)
                image = SimpleITK.GetArrayFromImage(SimpleITK.Tile(imgT1Original[:, :, idxSlice],(2, 1, 0))) 
                test.lana(image) 
                features = FeatureExtract(image) 
                prediction = clf.predict(features.reshape(1, -1))[0] 
                pred_labels.append(prediction) 
        y_train1 = traindata
        y_pred = testdata
        accuracy = accuracy_score(y_train1, y_pred)
        recall = recall_score(y_train1, y_pred , average="binary")
        precision = precision_score(y_train1, y_pred , average="binary")
        f1 = f1_score(y_train1, y_pred , average="binary")


        mse = mean_squared_error(y_train1, y_pred)





        file_path = 'results.txt'
        if os.path.isfile(file_path):
                os.remove(file_path)
                with open('results.txt', 'w') as f:
                        f.write(str("Accuracy %.3f" %accuracy + '\n'))
                        f.write(str("Precision %.3f" %precision + '\n'))
                        f.write(str("Racall %.3f" %recall + '\n'))
                        f.write(str("FScore %.3f" %f1 + '\n'))
        else:
                with open('results.txt', 'w') as f:
                        f.write(str("Accuracy %.3f" %accuracy + '\n'))
                        f.write(str("Precision %.3f" %precision + '\n'))
                        f.write(str("Racall %.3f" %recall + '\n'))
                        f.write(str("FScore %.3f" %f1 + '\n'))
        
        
        file_path = 'mse.txt'
        if os.path.isfile(file_path):
                os.remove(file_path)
                with open('mse.txt', 'w') as f:
                        f.write(str("MSE %.3f" %mse))

        else:
                with open('mse.txt', 'w') as f:
                        f.write(str("MSE %.3f" %mse))


        return(0)
        
        #print ("Accuracy %.3f" %accuracy)
        #print("Precision %.3f" %precision)
        #print("MSE %.3f" %mse)
        #print("fscore %.3f" %f1)



        #import pandas as pd

        #clsf_report = pd.DataFrame(classification_report(y_true = y_train1, y_pred = y_pred, output_dict=True)).transpose()
        #clsf_report.to_csv('Your Classification Report Name.csv', index= True)


        """======================
        Segmentation Results:
        ======================
        Accuracy
        0.929

        Precision
        0.998

        Racall
        0.915

        MSE 0.071
        MAE 0.071
        """




"""
def FeatureExtract(image):
        textures = mt.features.haralick(image)
        mean = textures.mean(axis=0)       
        return mean 

train_path1 = "data/train"
train_path = train_path1 + "/list"
pathd = r'%s' % train_path1 + "/list.txt"


test_path1 = "data/train"
train_path = test_path1 + "/list"
pathd = r'%s' % test_path1 + "/list.txt"


#pathd=r"data/train/list.txt"
#patht=r"data/test/list.txt"


warnings.filterwarnings("ignore")      
train_names = os.listdir(train_path) 
print (train_names)
train_features = []
train_labels = []
i = 1
idxSlice = 50
traindata = pd.read_csv(pathd)
testdata = pd.read_csv(patht)
print ("Texture Extraction...")
for train_name in train_names:
        cur_path = train_path + "/" + train_name
        cur_label = train_name	
        i = 1
        for fileName in glob.glob(train_path + "/*.mha"): 
                print ("Process image - {} in {}".format(i, cur_label))
                imgT1Original = SimpleITK.ReadImage(fileName)
                image = SimpleITK.GetArrayFromImage(SimpleITK.Tile(imgT1Original[:, :, idxSlice],(2, 1, 0))) 
                seg = cv2.imread("seg1"+str(i)+".png") 
                features = FeatureExtract(image) 
                train_features.append(features)
                train_labels.append(cur_label)
                i += 1 

#clf_svm = LinearSVC(random_state = 9) 
clf = RandomForestClassifier(max_depth=2, random_state = 9)
clf.fit(train_features, train_labels) 

test_label = [] 
pred_labels = [] 
print ("Process Test model...")
for fileName in glob.glob(test_path + "/*.mha"):
        test_label = os.listdir(test_path)

        imgT1Original = SimpleITK.ReadImage(fileName)
        image = SimpleITK.GetArrayFromImage(SimpleITK.Tile(imgT1Original[:, :, idxSlice],(2, 1, 0))) 
        #test2.lana(image) 
        features = FeatureExtract(image) 
        prediction = clf.predict(features.reshape(1, -1))[0] 
        pred_labels.append(prediction) 
y_train1 = traindata
y_pred = testdata
accuracy = accuracy_score(y_train1, y_pred)
recall = recall_score(y_train1, y_pred , average="binary")
precision = precision_score(y_train1, y_pred , average="binary")
f1 = f1_score(y_train1, y_pred , average="binary")


mse = mean_squared_error(y_train1, y_pred)





file_path = 'results.txt'
if os.path.isfile(file_path):
        os.remove(file_path)
        with open('results.txt', 'w') as f:
                f.write(str("Accuracy %.3f" %accuracy + '\n'))
                f.write(str("Precision %.3f" %precision + '\n'))
                f.write(str("Racall %.3f" %recall + '\n'))
                f.write(str("FScore %.3f" %f1 + '\n'))
else:
        with open('results.txt', 'w') as f:
                f.write(str("Accuracy %.3f" %accuracy + '\n'))
                f.write(str("Precision %.3f" %precision + '\n'))
                f.write(str("Racall %.3f" %recall + '\n'))
                f.write(str("FScore %.3f" %f1 + '\n'))




print ("Accuracy %.3f" %accuracy)
print("Precision %.3f" %precision)
print("MSE %.3f" %mse)
print("fscore %.3f" %f1)



#import pandas as pd

#clsf_report = pd.DataFrame(classification_report(y_true = y_train1, y_pred = y_pred, output_dict=True)).transpose()
#clsf_report.to_csv('Your Classification Report Name.csv', index= True)

#======================
#Segmentation Results:
#======================
#Accuracy
#0.929

#Precision
#0.998

#Racall
#0.915

#MSE 0.071
#MAE 0.071


"""